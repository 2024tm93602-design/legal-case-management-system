# Legal Case Management System

## Description
A full-stack web application to manage legal cases.

## Tech Stack
- React
- Node.js
- MongoDB

## Run

Backend:
cd backend
npm install
node server.js

Frontend:
cd frontend
npm install
npm start
