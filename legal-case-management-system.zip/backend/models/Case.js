const mongoose = require("mongoose");

const caseSchema = new mongoose.Schema({
  title: String,
  client: String,
  court: String,
  status: String,
  nextHearingDate: String
});

module.exports = mongoose.model("Case", caseSchema);