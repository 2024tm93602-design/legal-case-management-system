const express = require("express");
const router = express.Router();
const Case = require("../models/Case");

router.post("/", async (req, res) => {
  const newCase = new Case(req.body);
  await newCase.save();
  res.json(newCase);
});

router.get("/", async (req, res) => {
  const cases = await Case.find();
  res.json(cases);
});

router.put("/:id", async (req, res) => {
  const updated = await Case.findByIdAndUpdate(req.params.id, req.body);
  res.json(updated);
});

router.delete("/:id", async (req, res) => {
  await Case.findByIdAndDelete(req.params.id);
  res.json("Deleted");
});

module.exports = router;