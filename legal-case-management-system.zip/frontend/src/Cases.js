import { useEffect, useState } from "react";
import axios from "axios";

function Cases() {
  const [cases, setCases] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/cases")
      .then(res => setCases(res.data));
  }, []);

  return (
    <div>
      <h2>All Cases</h2>
      {cases.map(c => (
        <div key={c._id}>
          <h3>{c.title}</h3>
          <p>{c.status}</p>
        </div>
      ))}
    </div>
  );
}

export default Cases;