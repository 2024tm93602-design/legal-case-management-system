function Dashboard() {
  return (
    <div>
      <h1>Legal Case Management System</h1>
      <a href="/cases">View Cases</a>
    </div>
  );
}

export default Dashboard;